Routing with Routific optimisation engine (nodejs version)
========================================================
How to run the code
——————————————————
1. CD into  100Order/routific in terminal window
2. Type “node team13.js”


View the output with maps
————————————————————————
1. Open 100Order/routific/routing.html (Use Chrome or Safari)


Calculate distance between two postal code using Google distance matrix
——————————————————
googleDistanceMatrix.html